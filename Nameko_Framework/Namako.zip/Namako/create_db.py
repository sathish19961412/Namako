from college import User,engine,Base

Base.metadata.create_all(engine)